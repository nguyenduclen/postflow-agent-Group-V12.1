# PostFlow Agent FINAL

Android Agent đồng bộ Chrome/Facebook với Panel PostFlow.

- Accessibility persistence across Agent Activity restart.
- Sticky Chrome/Facebook detection while Chrome remains active.
- Automatic Page detection and Page → Group discovery through Accessibility.
- Continuous Page/Group heartbeat sync to Panel.
- GitHub Actions workflow: `.github/workflows/build-apk.yml`.

Lưu ý: Facebook chỉ expose những Page/Group nào trong cây Accessibility; Agent không đọc cookie, mật khẩu hoặc dữ liệu đăng nhập.
