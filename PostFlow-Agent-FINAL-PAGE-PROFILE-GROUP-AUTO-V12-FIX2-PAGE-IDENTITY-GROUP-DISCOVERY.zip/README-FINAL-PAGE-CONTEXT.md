# PostFlow FINAL PAGE CONTEXT

This build does not use `facebook.com/` as proof of a Page.
The Android AccessibilityService inspects Chrome's Facebook accessibility tree for Page context and visible Group links.

## Important
Facebook mobile may keep the omnibox at `https://facebook.com/` after switching into a Page. The Agent therefore reports `page_detected`, `page_name`, `facebook_mode`, and `visible_groups_json` separately from `facebook_url`.

Only group links actually exposed in the accessibility tree are stored. The Agent does not read passwords, cookies, or credentials.

For the most reliable Group discovery, open the Page's Groups section in Chrome. Visible `/groups/...` links are then sent to the Panel automatically.
