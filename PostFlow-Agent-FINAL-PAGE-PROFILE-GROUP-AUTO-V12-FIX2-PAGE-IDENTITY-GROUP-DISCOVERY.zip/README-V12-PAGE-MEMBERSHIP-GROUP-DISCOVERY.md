# PostFlow Agent V12.1 — Page Identity + Group Discovery FIX2

## Sửa lỗi trọng yếu

1. **Không hạ Page → PROFILE chỉ vì một Accessibility tree tạm thời mất tên Page.** Chỉ downgrade khi Facebook thực sự expose tín hiệu profile rõ ràng.
2. Nếu Facebook expose URL Page trong Accessibility node/href dù omnibox chỉ là `facebook.com`, URL đó được dùng làm bằng chứng Page mạnh.
3. **Không bao giờ dùng `groupContextTrusted` của tree trước để tin tree sau.** Mỗi tree phải được xác minh lại trước khi đọc Group.
4. Một click `Groups/Nhóm` chỉ là candidate. Agent lưu chữ ký tree trước click và yêu cầu tree sau click thay đổi + có bằng chứng Groups.
5. Với Page, Group có thể là nhãn `Groups/Nhóm` chung nếu cùng màn hình chứng minh Page hiện tại; không còn bắt buộc tên Page phải nằm ngay trong clickable node.
6. Chỉ lấy Group card khi có URL `/groups/...` hoặc bằng chứng mạnh như `members/thành viên/public group/private group/joined/join group/leave group`.
7. Nếu tree là menu Facebook, Chrome tab switcher, feed hoặc Panel thì **không lấy bất kỳ Group nào**.
8. Khi đổi Page, toàn bộ Group session cũ bị xoá trước khi discovery Page mới bắt đầu.

## Kết quả mong muốn

- Profile → Page: `facebook_mode=PAGE`, đúng Page name/ID khi Facebook expose, sau đó mới tìm Page Groups.
- Page A → Page B: Group A không được tồn tại trong session của Page B.
- Page → Profile: Agent chỉ đổi về PROFILE khi có tín hiệu profile rõ ràng.
- Không tìm được Page Groups: `visible_groups_json=[]`, không lấy dữ liệu linh tinh.
